<?php

$locale_arr = array (
    "language" => "Spanish",
    "template" => array (
        "T_en_gb" => "Inglés (UK)",
        "T_en_us" => "Inglés (US)",
        "T_es_es" => "Español",
        "T_fr_fr" => "Francés",
        "T_fi_fi" => "Finlandés",
        "T_it_it" => "Italiano",
        "T_ar_ar" => "Árabe",
        "T_zh_cn" => "Chino (Simplificado)",
        "T_pt_br" => "Portugués Brasileño",
        ),
    );

?>
