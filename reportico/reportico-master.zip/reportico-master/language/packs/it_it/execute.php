<?php
$locale_arr = array (
"language" => "English",
"template" => array (
                "T_GO_BACK" => "Ritorno",
                "T_NO_DATA_FOUND" => "Nessun dato è stato trovato corrispondente ai criteri di",
                "T_UNABLE_TO_CONTINUE" => "Impossibile continuare",
                "T_INFORMATION" => "Informazioni",
                "T_GO_REFRESH" => "Rinfrescare",
                "T_GO_PRINT" => "Stampa",
                "T_NOTICE" => "Notifica",
                "T_REQUIRED_CRITERIA" => "È necessario fornire un valore per criteri voce",
        )
);
?>
