<?php
$g_translations = array (
		"en_gb" => array (
            ),
		"fr_fr" => array (
		   "Criteria" => "Crit�re",
			"Film" => "Filme",
			"Country" => "Pays",
			"Film Category" => "Categorie Du Film",
			"Film List (Tutorial 1 Stage 5)" => "La Liste Du Filme ( 1/5 ) ",
			"Loan History" => "La Historie Des Emplacements",
			"DVD Store Reporting System" => "La Systeme Du DVD",
			"All" => "Toute",
			"January" => "Janvier",
			"February" => "Fevrier",
			"Loaned Out" => "D'emplacee",
			"Debug" => "Debouge",
			"Unable To Continue:" => "Pas Possible De Continuer:",
			"Go Back" => "Retourner",
			"No Data was Found Matching Your Criteria" => "Rien D'Data",
			"Warning" => "Premonant",
			"Loaned" => "Emplacee",
			"Full Name" => "Nom en Plein",
			"Loan Count" => "Conte Empla",
			"Report Output" => "Conte Empla"
			)
		);

$g_report_desc = array ( "fr_fr" => array (
		"tut2_loanhistory.xml" =>
'
La <b>Report Du Emplacement Histoire</b> produit une liste des filmes bourree du libraire groupee par membre.
<p>
Il montre le suivant :-
<p>
1. 
 of adding a date range criteria by reporting on films that have been borrowed between the specified dates. It also demonstrates the use of setting date range defaults.
<p>
2. use of a LIST type criteria item
<p>
3. conditional assignment by displaying "UNRETURNED" in the return date column instead of a normal blank
'
			)
		);
?>
